import dash
from dash import dcc,html
import dash_bootstrap_components as dbc
from dash_bootstrap_components._components.Col import Col
from dash_bootstrap_components._components.Row import Row
import pandas as pd 
import plotly.express as px
from dash.dependencies import Input,Output
def plot_graph(app,data):
    x='Date'
    data[x]=pd.to_datetime(data[x])
    data['year'] = data[x].dt.year
    # print(data.year)
    data['year_i'] = (data.year / 10).astype(int)
    data['isMil'] = data.Operator.str.contains('MILITARY', case=False)
    data.isMil.fillna(False,inplace=True)
    year_range = range(min(data['year_i'] ),max(data['year_i'] )+1,1)
    markers = {x*10:str(x*10) for x in year_range}
    slider = dcc.Slider(
        id='year_select',
        min=min(data['year_i'] )*10,
        max=max(data['year_i'] )*10+5,
        value = 2000,
        step=10,
        marks=markers,
    )
    dropdown =dcc.Dropdown(
        id='dropdown',
        options=[
            {'label': 'Military', 'value': 'Military'},
            {'label': 'Non-Militray', 'value': 'Non-Militray'},
            {'label': 'All', 'value': 'All'},
        ],
        value='All',
        clearable=False
    ),
    title = 'Accidents over Time'
    graph = px.histogram(data_frame=data,x='year',title='')
    graph_area = dcc.Graph(id='accidents_time',figure=graph)
    graph_element = dbc.Card(
        [
            dbc.Row([
                dbc.Col(html.H5("Accident Type: "),sm=5),
                dbc.Col(dropdown,sm=7)
            ]),
            graph_area,
            dbc.Row([
                dbc.Col(html.H5("Select Decade: "),sm=4),
                dbc.Col(slider,sm=8),
            ]),
        ],
        body=True,
        
    )
    @app.callback(
        Output('accidents_time','figure'),
        Input('year_select','value'),
        Input('dropdown','value')
    )
    def _updateGraph(sliderValue,dropdownValue):
        i = sliderValue / 10
        temp_data = data[data.year_i == i]
        if(dropdownValue == 'Military'):
            temp_data = temp_data[temp_data.isMil]
        elif(dropdownValue == 'Non-Militray'):
            temp_data = temp_data[temp_data.isMil != True]

        fig = px.histogram(
                            x='Date',title='{} {} {}s'.format(dropdownValue,title,sliderValue),
                            data_frame=temp_data,
                        )
        return fig
    return graph_element