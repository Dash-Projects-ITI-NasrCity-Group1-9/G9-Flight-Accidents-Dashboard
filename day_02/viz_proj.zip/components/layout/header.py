import dash
from dash import dcc,html
import dash_bootstrap_components as dbc
import pandas as pd 

title = html.H1(
    children="Flights Dashboard",
    className='title'
)