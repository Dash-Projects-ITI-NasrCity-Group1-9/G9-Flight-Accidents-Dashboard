import dash
from dash import dcc,html
import dash_bootstrap_components as dbc
import pandas as pd 
from components.layout.footer import footer
from components.layout.header import title
from components.graphs.accident_over_time import plot_graph as accident_time_plot
from components.graphs.accident_over_types import plot_graph as accident_type_plot
import os



# import plotly.express as px 
df = pd.read_csv('./data/Airplane_Crashes_and_Fatalities_Since_1908.csv')

app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP,'./assets/style.css'])
app.layout = dbc.Container(
    children=[
        title,
        
        html.Hr(),
        dbc.Row(
            [
                dbc.Col(accident_time_plot(app,df), md=6,lg=8),
                dbc.Col(accident_type_plot(app,df), md=6,lg=4),
            ],
            # align="center",
        ),
        footer
    ],
    fluid=True,
)
if __name__ == '__main__':
    app.run_server(debug=True)